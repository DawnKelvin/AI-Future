import os
import time
import numpy as np
from PIL import Image
import tflite_runtime.interpreter as tflite

# ========== CONFIG ==========
MODEL_PATH = "model.tflite"
LABELS_PATH = "labels.txt"
IMAGE_PATH = "test.jpg"
IMAGE_SIZE = (128, 128)
USE_CAMERA = True   # Set to False to use existing image
# ============================

def load_labels(path):
    with open(path, "r") as f:
        return [line.strip() for line in f.readlines()]

def preprocess_image(image_path):
    img = Image.open(image_path).resize(IMAGE_SIZE)
    img = np.array(img).astype(np.float32) / 255.0
    return np.expand_dims(img, axis=0)

def capture_image(output_path):
    from picamera import PiCamera
    camera = PiCamera()
    camera.start_preview()
    time.sleep(2)  # warm-up time
    camera.capture(output_path)
    camera.stop_preview()
    print(f"Image captured: {output_path}")

def speak(text):
    os.system(f'espeak "{text}"')

def run_inference():
    # Load TFLite model
    interpreter = tflite.Interpreter(model_path=MODEL_PATH)
    interpreter.allocate_tensors()

    # Get input/output tensor details
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # Capture or load image
    if USE_CAMERA:
        capture_image(IMAGE_PATH)

    input_data = preprocess_image(IMAGE_PATH)
    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()

    # Get prediction
    output_data = interpreter.get_tensor(output_details[0]['index'])[0]
    prediction_idx = np.argmax(output_data)
    confidence = output_data[prediction_idx]

    # Load labels
    labels = load_labels(LABELS_PATH)
    predicted_label = labels[prediction_idx]

    # Output result
    print(f"Prediction: {predicted_label} ({confidence*100:.2f}%)")
    speak(f"I think it's {predicted_label}")

if __name__ == "__main__":
    run_inference()
